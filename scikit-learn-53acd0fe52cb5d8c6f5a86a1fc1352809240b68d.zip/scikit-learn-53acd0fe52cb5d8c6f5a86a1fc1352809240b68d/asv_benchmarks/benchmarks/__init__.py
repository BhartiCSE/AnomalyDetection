"""Benchmark suite for scikit-learn using ASV"""
